//
//  SceneDelegate.h
//  EZWiFiConfigDemo
//
//  Created by yuqian on 2020/4/26.
//  Copyright © 2020 com.hikvision.ezviz. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

